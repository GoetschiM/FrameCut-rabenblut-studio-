@echo off
call "%~dp0FrameCut-Worker.bat" %*
